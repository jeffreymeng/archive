//
//  ViewController.m
//  ImageFollowingFinger
//
//  Created by Josip Petric on 11/4/12.
//  Copyright (c) 2012 josip.petric1@gmail.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize imageView;

- (void)viewDidLoad
{
    [super viewDidLoad];
	[self.view setBackgroundColor:
		[UIColor colorWithRed:0 green:0.4 blue:0 alpha:1]];
	// create image that will be shown on the screen
	imageView = [[UIImageView alloc] 
		initWithImage:[UIImage imageNamed:@"ball_big.png"]];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
	[self setImageView:nil];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [[event touchesForView:self.view] anyObject];
	// get the location of a touch event
	CGPoint point = [touch locationInView:self.view];
	
	if (imageView != nil) {
		[imageView removeFromSuperview];
	}
	
	// show image on the screen where user touched
	[self.view addSubview:imageView];
	imageView.center = point;
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	// get current touch location
	UITouch *touch = [[event touchesForView:self.view] anyObject];
	CGPoint point = [touch locationInView:self.view];
	// update location of the image
	imageView.center = point;
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	// remove image from the screen - this is optional
	[imageView removeFromSuperview];
	// some custom action activated when finger is lifted
	UIAlertView *alert = [[UIAlertView alloc] 
			initWithTitle:@"Moving Stopped" 
			message:@"Finger has been lifted off the screen." 
			delegate:nil cancelButtonTitle:@"OK" 
			otherButtonTitles: nil];
	[alert show];
}


@end
