//
//  ViewController.h
//  ImageFollowingFinger
//
//  Created by Josip Petric on 11/4/12.
//  Copyright (c) 2012 josip.petric1@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) UIImageView *imageView;

@end
